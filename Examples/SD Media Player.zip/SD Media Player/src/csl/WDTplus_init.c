/*
 *  ==== DO NOT MODIFY THIS FILE - CHANGES WILL BE OVERWRITTEN ====
 *
 *  Generated from
 *      D:/Program Files/Texas Instruments/grace_1_10_00_17/packages/ti/mcu/msp430/csl/watchdog/WDTplus_init.xdt
 */

#include <msp430.h>

/*
 *  ======== WDTplus_init ========
 *  Initialize MSP430 Watchdog Timer+
 */
void WDTplus_init(void)
{
    /* 
     * WDTCTL, Watchdog Timer+ Register
     * 
     * ~WDTHOLD -- Watchdog timer+ is not stopped
     * ~WDTNMIES -- NMI on rising edge
     * ~WDTNMI -- Reset function
     * WDTTMSEL -- Interval timer mode
     * ~WDTCNTCL -- No action
     * ~WDTSSEL -- SMCLK
     * ~WDTIS0 -- Watchdog clock source bit0 disabled
     * WDTIS1 -- Watchdog clock source bit1 enabled
     * 
     * Note: ~<BIT> indicates that <BIT> has value zero
     */
    WDTCTL = WDTPW + WDTTMSEL + WDTIS1;
    
}
