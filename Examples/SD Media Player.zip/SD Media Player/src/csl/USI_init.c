/*
 *  ==== DO NOT MODIFY THIS FILE - CHANGES WILL BE OVERWRITTEN ====
 *
 *  Generated from
 *      D:/Program Files/Texas Instruments/grace_1_10_00_17/packages/ti/mcu/msp430/csl/communication/USI_init.xdt
 */

#include <msp430.h>

/*
 *  ======== USI_init ========
 *  Initialize Universal Serial Interface
 */
void USI_init(void)
{
    /* USI is not initialized yet */
}
