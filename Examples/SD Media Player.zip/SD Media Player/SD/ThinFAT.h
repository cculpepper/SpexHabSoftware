//*****************************************************************************
//
// Title		: Thin FAT File System
// Author		: Matthew Rogan
// Created		: 22/03/2012
//
// This code is distributed under the GNU Public License
// which can be found at http://www.gnu.org/licenses/gpl.txt
//*****************************************************************************

// char ThinFATFileChecker(8 char array, 3 char array)
// 					--- function ---
// When ThinFATFindFile() is run, it loads the cluster of the
// current directory and for each file in that folder it then
// runs the callback using this template. it allows your
// code to check each file if it is the file you need.  when
// you return ThinFAT_Success on any of the files it will
// stop and stream that file.
//					--- Variables ---
// Return ThinFAT_Success to stream that file, otherwise
// ThinFAT_Fail to reject that file.
// The first char array is the 8 letter FAT16 filename
// The second char array is the 3 letter FAT16 extension
typedef char(*ThinFATFileChecker)(unsigned char Filename[],unsigned char Extension[]);

// Callback for when the current file ends
typedef void(*ThinFATFileEnd)(void);

// Initialises the FAT16 filesystem and the SD card, acting as a
// abstraction layer between the SD card and the user code
void ThinFAT_Init();

// Reads a byte from the SD card
char ThinFATReadByte();

// Reads a big-endian Int from the SD card
int ThinFATReadbInt();

// Reads a big-endian Long from the SD card
long ThinFATReadbLong();

// Reads a little-endian Int from the SD card
int ThinFATReadlInt();

// Reads a little-endian Long from the SD card
long ThinFATReadlLong();

// Checks if there is an active file
char ThinFAT_ActiveFile();

// Opens a file for streaming
void ThinFAT_OpenFile( int StartCluster, long FileSize );

// Sets the current folder
void ThinFAT_OpenFolder( int StartCluster, int FolderSize );

// Set the Current Folder to the Root Folder
void ThinFAT_OpenRootFolder();

// Close current file before end of the file
void ThinFAT_CloseFile();

// searches for Entry's in the current folder with the given
// attributes like ThinFAT_File, ThinFAT_Folder.  then opens it
// as the current streaming file if the user callback evaluates
// as true.
void ThinFAT16Search(ThinFATFileChecker ThinFATChecker, char Attributes);

// searches current directory for files and calls back to the
// user code to check if the current file is the correct one
// this file is then opened for streaming if it's true.
void ThinFAT_FindFile(ThinFATFileChecker ThinFATChecker, ThinFATFileEnd ThinFATEndOfFile);

// searches current directory for folders and calls back to
// the user code to check each entry's name, if it evaluates
// as true it stops and then loads it as the current folder
void ThinFATFindFolder(ThinFATFileChecker ThinFATChecker);

// This shows how many sectors into the file the streamer is
long ThinFAT_FileProgress();

// This gives the file size in sectors
long ThinFAT_FileSize();

// File Attributes for file searches
#define ThinFAT_File   		 	0x00
#define ThinFAT_ReadOnly		0x01
#define ThinFAT_Folder			0x10
#define ThinFAT_Volume			0x08
#define ThinFAT_Archive			0x20

// System Messages
#define ThinFAT_Fail			0x00
#define ThinFAT_Success			0x01

// Filesystem modes
#define ThinFAT_FileSystem		0x04
#define ThinFAT_FileStream		0x08
#define ThinFAT_FileActive		0x10
