//*****************************************************************************
//
// Title		: Thin FAT File System
// Author		: Matthew Rogan
// Created		: 22/03/2012
//
// This code is distributed under the GNU Public License
// which can be found at http://www.gnu.org/licenses/gpl.txt
//*****************************************************************************

#include "mmc.h"
#include "ThinFAT.h"

// total ram use 54 bytes

// Current Loaded File System 14 bytes
struct sThinFAT16FS {
	unsigned long BootSector;				// First sector of FAT16 Partition
	unsigned char FatSector;				// Sector of first FAT
	unsigned int RootSector;				// Sector of Root Directory
	unsigned int FirstCluster;				// Sector of First Cluster
	unsigned char ClusterSize;				// Sectors in Each cluster
	unsigned char ClusterShift;				// power of 2 of the cluster size
	unsigned int RootEntrys;				// Count of entry's in Root Directory
	unsigned char SDStatus;					// SD card status
} ThinFAT16FS;

// Current Streaming File 27 bytes
struct sThinFAT16File {
	unsigned char Filename[8];				// Name of file
	unsigned char Extension[3];				// File Extension
	unsigned char Attributes;				// File Attributes
	unsigned char mode;						// status of Filesystem
	unsigned int CurrentByte;				// current byte
	unsigned int FirstSector;				// First Sector
	unsigned long CurrentSector;			// current Sector
	unsigned long LastSector;				// last Sector
	ThinFATFileEnd EndOfFile;				// Callback when file ends
} ThinFAT16File;

// Current Directory 6 bytes
struct sThinFAT16Folder {
	unsigned int StartCluster;				// Starting cluster of directory
	unsigned long FolderSize;				// Last byte in directory
} ThinFAT16Folder;

// Temp files of ThinFAT16 7 bytes
struct sThinFAT16Temp {
	unsigned char A;
	unsigned int B;
	unsigned long C;
} ThinFAT16Temp;

// Function Prototypes
void ThinFAT_Init();
char ThinFATReadByte();
int ThinFATReadbInt();
int ThinFATReadlInt();
long ThinFATReadbLong();
long ThinFATReadlLong();
char ThinFAT_ActiveFile();
void ThinFAT_OpenFile( int StartCluster, long FileSize );
void ThinFAT_OpenFolder( int StartCluster, int FolderSize );
void ThinFAT_OpenRootFolder();
void ThinFAT_CloseFile();
void ThinFAT16Search(ThinFATFileChecker ThinFATChecker, char Attributes);
void ThinFAT_FindFile(ThinFATFileChecker ThinFATChecker, ThinFATFileEnd ThinFATEndOfFile);
void ThinFAT_FindFolder(ThinFATFileChecker ThinFATChecker);
long ThinFAT_FileProgress();
long ThinFAT_FileSize();
void ThinFAT_EndOfFileShell();

// Start up the SD card and Load Up the FAT Filesystem from it
void ThinFAT_Init()
{
	// Initialise SPI with the SD card
	MMC_initSPI();
	ThinFAT16FS.SDStatus=MMC_OTHER_ERROR;
	while(ThinFAT16FS.SDStatus!=MMC_SUCCESS)
	{
		MMC_initSPI();
		ThinFAT16FS.SDStatus=initMMC();
	}

	// Initilise variables
	ThinFAT16File.CurrentSector = 0;
	ThinFAT16File.CurrentByte = 0;
	//ThinFAT16File.LastByte = 512;
	//ThinFAT16File.LastCluster = 0;
	ThinFAT16File.LastSector = ThinFAT16File.CurrentSector + 1;
	ThinFAT16File.EndOfFile = ThinFAT_EndOfFileShell;	// reset to blank end of file pointer
	ThinFAT16File.mode &= ~ThinFAT_FileStream;			// Blank out File Stream

	// Reset the MBR Location
	ThinFAT16FS.BootSector = 0;

	// Read the MBR of SD Card
	while(ThinFAT16File.CurrentByte!=512)
	{
		switch(ThinFAT16File.CurrentByte)
		{
		/*
		case 0x01C2:
			// Get the partition type
			ThinFAT16Temp.A = ThinFATReadByte();
			break;
			*/
		case 0x01C6:
			// check if it's a valid FAT16 partition
			//if(((ThinFAT16Temp.A==0x04) || (ThinFAT16Temp.A==0x06)) && Partition==1)
			//{
				//Retrieve LBA Address of partition
				ThinFAT16FS.BootSector = ThinFATReadlLong();
			//}else{ThinFATReadByte();}
			break;
			/*
		case 0x01D2:
			// Get the partition type
			ThinFAT16Temp.A = ThinFATReadByte();
			break;
		case 0x01D6:
			// check if it's a valid FAT16 partition
			if(((ThinFAT16Temp.A==0x04) || (ThinFAT16Temp.A==0x06)) && Partition==2)
			{
				//Retrieve LBA Address of partition
				ThinFAT16FS.BootSector = ThinFATReadlLong();
			}else{ThinFATReadByte();}
			break;
		case 0x01E2:
			// Get the partition type
			ThinFAT16Temp.A = ThinFATReadByte();
			break;
		case 0x01E6:
			// check if it's a valid FAT16 partition
			if(((ThinFAT16Temp.A==0x04) || (ThinFAT16Temp.A==0x06)) && Partition==3)
			{
				//Retrieve LBA Address of partition
				ThinFAT16FS.BootSector = ThinFATReadlLong();
			}else{ThinFATReadByte();}
			break;
		case 0x01F2:
			// Get the partition type
			ThinFAT16Temp.A = ThinFATReadByte();
			break;
		case 0x01F6:
			// check if it's a valid FAT16 partition
			if(((ThinFAT16Temp.A==0x04) || (ThinFAT16Temp.A==0x06)) && Partition==4)
			{
				//Retrieve LBA Address of partition
				ThinFAT16FS.BootSector = ThinFATReadlLong();
			}else{ThinFATReadByte();}
			break;
			*/
		default:
			// skip boring bits
			ThinFATReadByte();
			break;
		}
	}

	// Prepare for reading First partition
	ThinFAT16File.CurrentSector = ThinFAT16FS.BootSector;
	ThinFAT16File.LastSector = ThinFAT16File.CurrentSector + 1;
	ThinFAT16File.CurrentByte = 0;
	ThinFAT16File.mode &= ~ThinFAT_FileStream;

	// Read the Boot Partition
	while(ThinFAT16File.CurrentByte!=512)
	{
		// check which byte is being read
		switch(ThinFAT16File.CurrentByte)
		{
		case 0x0d:						// Sectors Per Cluster
			ThinFAT16FS.ClusterSize = ThinFATReadByte();
			break;
		case 0x0e:						// Reserved Sectors
			ThinFAT16FS.FatSector = ThinFAT16FS.BootSector + ThinFATReadlInt();
			break;
		case 0x10:						// Number of FATs
			ThinFAT16Temp.A = ThinFATReadByte();
			break;
		case 0x11:						// Number of Root Entry's
			ThinFAT16FS.RootEntrys = ThinFATReadlInt();
			break;
		case 0x16:						// Size of 1 copy of the FAT
			ThinFAT16Temp.B = ThinFATReadlInt();
			break;
		default:
			ThinFATReadByte();
			break;
		}
	}

	// The Root Sector is located after the fat
	ThinFAT16FS.RootSector = ThinFAT16FS.FatSector + (ThinFAT16Temp.A * ThinFAT16Temp.B);
	// The first cluster is located after the root directory, a sector is assumed to be 512 bytes
	// 32 bytes in a file entry, 512 bytes in a block becomes Entry count divided by 16
	ThinFAT16FS.FirstCluster = ThinFAT16FS.RootSector + ((ThinFAT16FS.RootEntrys) >> 4);
	// calculate cluster shift
	switch(ThinFAT16FS.ClusterSize)
	{
	case 2:
		ThinFAT16FS.ClusterShift = 1;
		break;
	case 4:
		ThinFAT16FS.ClusterShift = 2;
			break;
	case 8:
		ThinFAT16FS.ClusterShift = 3;
			break;
	case 16:
		ThinFAT16FS.ClusterShift = 4;
			break;
	case 32:
		ThinFAT16FS.ClusterShift = 5;
			break;
	case 64:
		ThinFAT16FS.ClusterShift = 6;
			break;
	case 128:
		ThinFAT16FS.ClusterShift = 7;
			break;
	default:
		ThinFAT16FS.ClusterShift = 0;
			break;
	}
	// Load Root Folder as current Folder
	ThinFAT_OpenRootFolder();
	// Show Filesystem as Ready
	ThinFAT16File.mode &= ~ThinFAT_FileSystem;
}

void ThinFAT_OpenFile( int StartCluster, long FileSize )
{
	if(StartCluster!=0)
	{
		// Convert Cluster to sector
		ThinFAT16File.FirstSector = ThinFAT16FS.FirstCluster + ((StartCluster - 2) << ThinFAT16FS.ClusterShift);
		ThinFAT16File.CurrentSector = ThinFAT16File.FirstSector;
		// Get Last Sector
		ThinFAT16File.LastSector = ThinFAT16File.CurrentSector + (FileSize >> 9) + 1;
		// Rezero Current Byte
		ThinFAT16File.CurrentByte = 0;
	}else{
		// Set it to root directory
		ThinFAT16File.FirstSector = ThinFAT16FS.RootSector;
		ThinFAT16File.CurrentSector = ThinFAT16File.FirstSector;
		// Set to last sector
		ThinFAT16File.LastSector = ThinFAT16FS.FirstCluster;
		// Rezero Current Byte
		ThinFAT16File.CurrentByte = 0;
	}
	ThinFAT16File.mode &= ~ThinFAT_FileStream;
}

void ThinFAT_CloseFile()
{
	// Unmount current Block
	mmcUnmountBlock();
	// deactivate file stream
	ThinFAT16File.mode &= ~ThinFAT_FileStream;
	ThinFAT16File.mode &= ~ThinFAT_FileActive;
	// Return End of File Callback
	(*ThinFAT16File.EndOfFile)();
}

void ThinFAT_OpenFolder( int StartCluster, int FolderSize )
{
	// Load Variables into filestream
	ThinFAT16Folder.StartCluster = StartCluster;
	ThinFAT16Folder.FolderSize = FolderSize;
}

void ThinFAT_OpenRootFolder()
{
	ThinFAT_OpenFolder( 0, ((ThinFAT16FS.RootEntrys) << 5) );
}

char ThinFATReadByte()
{
	// Check if it's the end of a block
	if((ThinFAT16File.CurrentByte&511)==0)
	{
		if ((ThinFAT16File.mode&ThinFAT_FileStream)!=ThinFAT_FileStream)
		{
			ThinFAT16File.mode |= ThinFAT_FileStream;
		}else{
			mmcUnmountBlock();
			ThinFAT16File.CurrentSector++;
		}
		if(ThinFAT16File.CurrentSector==ThinFAT16File.LastSector)
		{
			// deactivate file stream
			ThinFAT16File.mode &= ~ThinFAT_FileStream;
			ThinFAT16File.mode &= ~ThinFAT_FileActive;
			// Return End of File Callback
			(*ThinFAT16File.EndOfFile)();
			// return a blank
			return 0x00;
		}else{
			ThinFAT16FS.SDStatus = MMC_OTHER_ERROR;
			while( ThinFAT16FS.SDStatus!=MMC_SUCCESS )
			{
				ThinFAT16FS.SDStatus=mmcMountBlock(((ThinFAT16File.CurrentSector) << 9));
			}
		}
	}
	// increment current byte
	ThinFAT16File.CurrentByte++;
	// Return the byte Value
	return mmcReadByte();
}
int ThinFATReadbInt()
{
	ThinFAT16Temp.B = ThinFATReadByte();
	ThinFAT16Temp.B = ThinFAT16Temp.B << 8;
	ThinFAT16Temp.B += ThinFATReadByte();
	return ThinFAT16Temp.B;
}
int ThinFATReadlInt()
{
	ThinFAT16Temp.B = ThinFATReadByte();
	ThinFAT16Temp.B += (unsigned int)ThinFATReadByte() << 8;
	return ThinFAT16Temp.B;
}
long ThinFATReadbLong()
{
	ThinFAT16Temp.C = ThinFATReadByte();
	ThinFAT16Temp.C = ThinFAT16Temp.C << 8;
	ThinFAT16Temp.C += ThinFATReadByte();
	ThinFAT16Temp.C = ThinFAT16Temp.C << 8;
	ThinFAT16Temp.C += ThinFATReadByte();
	ThinFAT16Temp.C = ThinFAT16Temp.C << 8;
	ThinFAT16Temp.C += ThinFATReadByte();
	return ThinFAT16Temp.C;
}
long ThinFATReadlLong()
{
	ThinFAT16Temp.C = ThinFATReadByte();
	ThinFAT16Temp.C += (unsigned long)ThinFATReadByte() << 8;
	ThinFAT16Temp.C += (unsigned long)ThinFATReadByte() << 16;
	ThinFAT16Temp.C += (unsigned long)ThinFATReadByte() << 24;
	return ThinFAT16Temp.C;
}

void ThinFAT16Search(ThinFATFileChecker ThinFATChecker, char Attributes)
{
	// rezero end of file pointer
	ThinFAT16File.EndOfFile = ThinFAT_EndOfFileShell;
	// Load the Current directory like you would a file
	ThinFAT_OpenFile( ThinFAT16Folder.StartCluster, ThinFAT16Folder.FolderSize );
	// set Temp characters to fail so that loop runs once
	ThinFAT16Temp.A = ThinFAT_Fail;
	ThinFAT16File.Filename[0] = 0xE5;

	// Loop through each entry
	while((ThinFAT16Temp.A!=ThinFAT_Success) && ThinFAT16File.Filename[0]!=0x00)
	{
		// Read filename
		for (ThinFAT16Temp.B = 0;8>ThinFAT16Temp.B;ThinFAT16Temp.B++)
		{
			ThinFAT16File.Filename[ThinFAT16Temp.B] = ThinFATReadByte();
		}
		// Read file extension
		for (ThinFAT16Temp.B = 0;3>ThinFAT16Temp.B;ThinFAT16Temp.B++)
		{
			ThinFAT16File.Extension[ThinFAT16Temp.B] = ThinFATReadByte();
		}
		// Read attributes
		ThinFAT16File.Attributes = ThinFATReadByte();
		// skip file details
		for (ThinFAT16Temp.B = 0;14>ThinFAT16Temp.B;ThinFAT16Temp.B++)
		{
			ThinFATReadByte();
		}
		// read file start location
		ThinFAT16Temp.B = ThinFATReadlInt();
		// read file size, separate clusters from bytes with a bitmask
		ThinFAT16Temp.C = ThinFATReadlLong();
		// check if it has the same attributes excluding archive bit
		if ((ThinFAT16File.Attributes&~ThinFAT_Archive)==Attributes && ThinFAT16File.Filename[0]!=0xE5)
		{
			// Test if this file works
			ThinFAT16Temp.A = (*ThinFATChecker)(ThinFAT16File.Filename,ThinFAT16File.Extension);
		}else{
			// return a fail due to attributes mismatch
			ThinFAT16Temp.A = ThinFAT_Fail;
		}
	}
	// unmount block
	mmcUnmountBlock();
	// Close Filestream
	ThinFAT16File.mode &= ~ThinFAT_FileStream;
	// Check if a file was sucessfully found
	if(ThinFAT16Temp.A==ThinFAT_Success)
	{
		if(Attributes!=ThinFAT_Folder)
		{
			ThinFAT_OpenFile( ThinFAT16Temp.B, ThinFAT16Temp.C );
			// set current file active
			ThinFAT16File.mode |= ThinFAT_FileActive;
		}else{
			ThinFAT_OpenFolder( ThinFAT16Temp.B, ThinFAT16Temp.C );
		}
	}
}

char ThinFAT_ActiveFile()
{	if ((ThinFAT16File.mode&ThinFAT_FileActive)==ThinFAT_FileActive)
	{	return ThinFAT_Success;
	}else{
		return ThinFAT_Fail;}
}

void ThinFAT_FindFile(ThinFATFileChecker ThinFATChecker, ThinFATFileEnd ThinFATEndOfFile)
{
	// Search for indexes of given attributes in the current folder
	ThinFAT16Search( ThinFATChecker, ThinFAT_File );
	if ((ThinFAT16File.mode&ThinFAT_FileActive)!=ThinFAT_FileActive)
	{
		ThinFAT16Search( ThinFATChecker, ThinFAT_ReadOnly );
	}
	// Add End of file callback
	ThinFAT16File.EndOfFile = ThinFATEndOfFile;
}

void ThinFAT_FindFolder(ThinFATFileChecker ThinFATChecker)
{
	ThinFAT16Search( ThinFATChecker, ThinFAT_Folder );
}

long ThinFAT_FileProgress()
{
	return (ThinFAT16File.CurrentSector - ThinFAT16File.FirstSector);
}

long ThinFAT_FileSize()
{
	return (ThinFAT16File.LastSector - ThinFAT16File.FirstSector);
}

void ThinFAT_EndOfFileShell()
{

}

