/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-x20
 */

#ifndef xconfig_main__
#define xconfig_main__



#endif /* xconfig_main__ */ 
