/*
 * ======== Standard MSP430 includes ========
 */
#include <msp430.h>
#include "SD\ThinFAT.h"

unsigned char Mode;
struct sPlaylist {
	unsigned int CurrentFile;
	unsigned int FileCount;
	unsigned int FileIndex;
} Playlist;

struct AudioPort {
	unsigned char Left;
	unsigned char Right;
} audioOut;

void Next_Sample(void);
void Sync_Left_Sample();
void Sync_Right_Sample();
char IndexWavFile(unsigned char Filename[],unsigned char Extension[]);
char CheckWavFile(unsigned char Filename[],unsigned char Extension[]);
void PlayWavFile();
void EndWavFile();
void Button_Pushed(void);

/*
 * ======== Grace related includes ========
 */
#include <ti/mcu/msp430/csl/CSL.h>

/*
 *  ======== main ========
 */
int main()
{
    CSL_init();                     // Activate Grace-generated configuration
    
    // Start Up code
    WDTCTL = WDTPW + WDTHOLD;		// set the watchdog to hold
    // Rezero amount of files
    Playlist.FileCount = 0;
    // Initilise Filesystem and SD card
    ThinFAT_Init();
    // Index Files
    ThinFAT_FindFile((*IndexWavFile), (*EndWavFile));
    // Main Loop

    for (;;)
    {
    	// Play once then sleep
    	// PlayWavFile();
    	LPM0;
    }
}

void Next_Sample(void)
{
	// Load sample into buffer
	audioOut.Left = ThinFATReadByte();
	audioOut.Right = audioOut.Left;
	// audioOut.Right = ThinFATReadByte();
	// audioOut.CurrentSample = ThinFATReadByte();
}

// Loading
void Sync_Left_Sample()
{
	CCR1 = audioOut.Left;
	// CCR1 = audioOut.CurrentSample;
}

void Sync_Right_Sample()
{
	CCR2 = audioOut.Right;
	// CCR2 = audioOut.CurrentSample;
}

char IndexWavFile(unsigned char Filename[],unsigned char Extension[])
{
	if(Extension[0]==87 && Extension[1]==65 && Extension[2]==86)
	{
		Playlist.FileCount++;
		Playlist.CurrentFile = 0;
	}
	return ThinFAT_Fail;
}

char CheckWavFile(unsigned char Filename[],unsigned char Extension[])
{
	if(Extension[0]==87 && Extension[1]==65 && Extension[2]==86)
	{
		if(Playlist.FileIndex==Playlist.CurrentFile)
		{
			Playlist.FileIndex=0;
			return ThinFAT_Success;
		}else
		{
			Playlist.FileIndex++;
			return ThinFAT_Fail;
		}
	}
	return ThinFAT_Fail;
}

void EndWavFile()
{
	WDTCTL = WDTPW + WDTHOLD;		// Pause Updating Samples
	// Check if file is active and close it
	if(ThinFAT_ActiveFile()==ThinFAT_Success)
	{	void ThinFAT_CloseFile();}
	Playlist.FileIndex=0;

}

void PlayWavFile()
{
	ThinFAT_FindFile((*CheckWavFile), (*EndWavFile));
	// enable updating sound samples
	WDTCTL = WDTPW + WDTTMSEL + WDTIS1;
}

void Button_Pushed(void)
{
	// Clear Interupt Register
	P1IFG &= ~BIT3;
	// If a file is playing, play next file
	// Also checks if it's 31 sectors (1 second) into playback
	if(ThinFAT_ActiveFile()==ThinFAT_Success && ThinFAT_FileProgress()>31 && ThinFAT_FileProgress()<(ThinFAT_FileSize()-155) )
	{
		// Increment File Count
		Playlist.CurrentFile++;
		// Check if File is end of the list
		if(Playlist.CurrentFile==Playlist.FileCount)
		{	Playlist.CurrentFile=0;}
	}
	// End Current Wav File
	EndWavFile();
	// Play Wav File
	PlayWavFile();
}

void Reset_Pushed(void)
{

}
